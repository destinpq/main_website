"use client"

import { useRef, useState, useEffect } from "react"
import { SafeMotion } from "@/components/framer-motion-safe"

interface AboutSectionProps {
  inView: boolean
}

export default function AboutSection({ inView }: AboutSectionProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const timelineEvents = [
    { year: "2018", title: "Company Founded", description: "Established with a vision to revolutionize AI solutions" },
    { year: "2019", title: "First Neural Network", description: "Launched our proprietary neural architecture" },
    { year: "2020", title: "Series A Funding", description: "$25M raised to accelerate R&D" },
    { year: "2021", title: "Global Expansion", description: "Opened offices in London, Tokyo, and Singapore" },
    { year: "2022", title: "AI Ethics Board", description: "Established industry-leading ethical guidelines" },
    {
      year: "2023",
      title: "Quantum AI Research",
      description: "Pioneered quantum computing integration with neural networks",
    },
    {
      year: "2024",
      title: "Fortune 500 Partnerships",
      description: "Strategic alliances with leading global enterprises",
    },
  ]

  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.2,
        duration: 0.8,
        ease: "easeOut",
      },
    }),
  }

  if (!isMounted) {
    return (
      <div ref={containerRef} className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 text-transparent bg-clip-text mb-6">
            Our Journey
          </h2>
          <p className="text-xl text-gray-300">
            From inception to innovation, we&apos;ve been at the forefront of AI evolution.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20">
      <SafeMotion
        className="text-center max-w-4xl mx-auto mb-16"
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        custom={0}
        variants={textVariants}
      >
        <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 text-transparent bg-clip-text mb-6">
          Our Journey
        </h2>
        <p className="text-xl text-gray-300">
          From inception to innovation, we&apos;ve been at the forefront of AI evolution.
        </p>
      </SafeMotion>

      {/* Timeline visualization (simplified) */}
      <SafeMotion
        className="w-full max-w-4xl mx-auto mb-16"
        initial={{ opacity: 0 }}
        animate={inView ? { opacity: 1 } : { opacity: 0 }}
        transition={{ duration: 1 }}
      >
        <div className="relative py-8">
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-cyan-500 to-purple-500"></div>

          {timelineEvents.map((event, index) => (
            <div key={index} className={`flex mb-12 ${index % 2 === 0 ? "justify-start" : "justify-end"}`}>
              <div className="relative w-1/2 px-4">
                <div
                  className="absolute top-0 w-4 h-4 rounded-full bg-cyan-500 shadow-glow-cyan"
                  style={{ [index % 2 === 0 ? "right" : "left"]: "-8px" }}
                ></div>
                <div className="bg-gray-900/50 backdrop-blur-sm border border-gray-800 rounded-lg p-4">
                  <h3 className="text-cyan-400 text-lg font-bold">{event.year}</h3>
                  <h4 className="text-white font-medium mb-1">{event.title}</h4>
                  <p className="text-gray-400 text-sm">{event.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </SafeMotion>

      <SafeMotion
        className="text-center max-w-4xl mx-auto mt-16"
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        custom={1}
        variants={textVariants}
      >
        <h3 className="text-2xl md:text-3xl font-bold text-white mb-4">Our Mission</h3>
        <p className="text-lg text-gray-300">
          To harness the power of artificial intelligence and create solutions that empower businesses to achieve
          unprecedented growth, efficiency, and innovation. We believe in responsible AI that serves humanity while
          pushing the boundaries of what&apos;s possible.
        </p>
      </SafeMotion>
    </div>
  )
}
