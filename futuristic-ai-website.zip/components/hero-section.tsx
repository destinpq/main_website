"use client"

import { useRef, useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { SafeMotion } from "@/components/framer-motion-safe"

interface HeroSectionProps {
  inView: boolean
}

export default function HeroSection({ inView }: HeroSectionProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.2,
        duration: 0.8,
        ease: "easeOut",
      },
    }),
  }

  if (!isMounted) {
    return (
      <div ref={containerRef} className="relative h-screen flex flex-col items-center justify-center px-4">
        <div className="relative z-10 text-center max-w-4xl mx-auto mt-32">
          <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-cyan-400 via-purple-500 to-blue-500 text-transparent bg-clip-text">
            Designing Tomorrow&apos;s Intelligence
          </h1>
          <p className="mt-6 text-xl md:text-2xl text-gray-300">
            Pioneering the future of AI and machine learning solutions that transform industries and redefine
            possibilities.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="relative h-screen flex flex-col items-center justify-center px-4">
      <div className="relative z-10 text-center max-w-4xl mx-auto mt-32">
        <SafeMotion
          className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-cyan-400 via-purple-500 to-blue-500 text-transparent bg-clip-text"
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          custom={0}
          variants={textVariants}
        >
          Designing Tomorrow&apos;s Intelligence
        </SafeMotion>

        <SafeMotion
          className="mt-6 text-xl md:text-2xl text-gray-300"
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          custom={1}
          variants={textVariants}
        >
          Pioneering the future of AI and machine learning solutions that transform industries and redefine
          possibilities.
        </SafeMotion>

        <SafeMotion
          className="mt-10 flex flex-col sm:flex-row gap-4 justify-center"
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          custom={2}
          variants={textVariants}
        >
          <Button
            size="lg"
            className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white border-none px-8 py-6 text-lg"
          >
            Explore Solutions
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-cyan-500 text-cyan-400 hover:bg-cyan-950/30 px-8 py-6 text-lg"
          >
            View Case Studies
          </Button>
        </SafeMotion>
      </div>

      {/* Scroll indicator */}
      <SafeMotion
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
      >
        <div className="w-8 h-12 rounded-full border-2 border-cyan-500 flex justify-center">
          <SafeMotion
            className="w-2 h-2 bg-cyan-500 rounded-full mt-2"
            animate={{ y: [0, 16, 0] }}
            transition={{ repeat: Number.POSITIVE_INFINITY, duration: 2 }}
          />
        </div>
      </SafeMotion>
    </div>
  )
}
