"use client"

import { useRef, useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { SafeMotion } from "@/components/framer-motion-safe"

interface CaseStudy {
  title: string
  client: string
  description: string
  image: string
  results: string[]
}

interface CaseStudiesSectionProps {
  inView: boolean
}

function CaseStudyCard({ caseStudy, index, inView }: { caseStudy: CaseStudy; index: number; inView: boolean }) {
  const cardRef = useRef<HTMLDivElement>(null)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const cardVariants = {
    hidden: { opacity: 0, y: 100 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        delay: index * 0.2,
        duration: 0.8,
        ease: "easeOut",
      },
    },
  }

  if (!isMounted) {
    return (
      <div ref={cardRef} className="w-full mb-32 last:mb-0">
        <div className="flex flex-col lg:flex-row gap-8 items-center">
          <div className="w-full lg:w-1/2 relative overflow-hidden rounded-xl">
            <div className="aspect-video bg-gradient-to-br from-purple-900 to-cyan-900 rounded-xl overflow-hidden">
              <img
                src={caseStudy.image || "/placeholder.svg"}
                alt={caseStudy.title}
                className="w-full h-full object-cover mix-blend-overlay opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
            </div>
          </div>

          <div className="w-full lg:w-1/2">
            <h3 className="text-3xl font-bold text-white mb-2">{caseStudy.title}</h3>
            <p className="text-cyan-400 mb-4">Client: {caseStudy.client}</p>
            <p className="text-gray-300 mb-6">{caseStudy.description}</p>

            <div className="mb-6">
              <h4 className="text-xl font-semibold text-white mb-3">Key Results:</h4>
              <ul className="space-y-2">
                {caseStudy.results.map((result, idx) => (
                  <li key={idx} className="flex items-start">
                    <span className="text-cyan-500 mr-2">•</span>
                    <span className="text-gray-300">{result}</span>
                  </li>
                ))}
              </ul>
            </div>

            <Button variant="outline" className="border-cyan-500 text-cyan-400 hover:bg-cyan-950/30">
              View Full Case Study <ArrowRight size={16} className="ml-2" />
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <SafeMotion
      ref={cardRef}
      variants={cardVariants}
      initial="hidden"
      animate={inView ? "visible" : "hidden"}
      className="w-full mb-32 last:mb-0"
    >
      <div className="flex flex-col lg:flex-row gap-8 items-center">
        <div className="w-full lg:w-1/2 relative overflow-hidden rounded-xl">
          <div className="aspect-video bg-gradient-to-br from-purple-900 to-cyan-900 rounded-xl overflow-hidden">
            <img
              src={caseStudy.image || "/placeholder.svg"}
              alt={caseStudy.title}
              className="w-full h-full object-cover mix-blend-overlay opacity-80"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
          </div>
        </div>

        <div className="w-full lg:w-1/2">
          <h3 className="text-3xl font-bold text-white mb-2">{caseStudy.title}</h3>
          <p className="text-cyan-400 mb-4">Client: {caseStudy.client}</p>
          <p className="text-gray-300 mb-6">{caseStudy.description}</p>

          <div className="mb-6">
            <h4 className="text-xl font-semibold text-white mb-3">Key Results:</h4>
            <ul className="space-y-2">
              {caseStudy.results.map((result, idx) => (
                <li key={idx} className="flex items-start">
                  <span className="text-cyan-500 mr-2">•</span>
                  <span className="text-gray-300">{result}</span>
                </li>
              ))}
            </ul>
          </div>

          <Button variant="outline" className="border-cyan-500 text-cyan-400 hover:bg-cyan-950/30">
            View Full Case Study <ArrowRight size={16} className="ml-2" />
          </Button>
        </div>
      </div>
    </SafeMotion>
  )
}

export default function CaseStudiesSection({ inView }: CaseStudiesSectionProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  const caseStudies: CaseStudy[] = [
    {
      title: "Predictive Maintenance Revolution",
      client: "Global Manufacturing Corp",
      description:
        "Implemented an advanced neural network system that predicts equipment failures before they occur, reducing downtime and maintenance costs.",
      image: "/placeholder.svg?height=600&width=800",
      results: [
        "Reduced unplanned downtime by 78%",
        "Saved $4.2M in annual maintenance costs",
        "Increased equipment lifespan by 35%",
        "ROI achieved within 6 months",
      ],
    },
    {
      title: "Customer Behavior Analysis",
      client: "Retail Chain Enterprises",
      description:
        "Developed a comprehensive AI system that analyzes customer behavior patterns across digital and physical touchpoints to optimize marketing strategies and personalize customer experiences.",
      image: "/placeholder.svg?height=600&width=800",
      results: [
        "Increased conversion rates by 42%",
        "Boosted customer retention by 28%",
        "Personalized recommendations led to 35% higher average order value",
        "Reduced customer acquisition costs by 23%",
      ],
    },
    {
      title: "Autonomous Decision System",
      client: "FinTech Innovations Inc.",
      description:
        "Created an AI-powered decision-making system that processes millions of financial transactions in real-time to detect fraud, assess risk, and automate approval processes.",
      image: "/placeholder.svg?height=600&width=800",
      results: [
        "Fraud detection accuracy increased to 99.7%",
        "Processing time reduced from hours to milliseconds",
        "Automated 87% of routine approval decisions",
        "Saved over 120,000 work hours annually",
      ],
    },
  ]

  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut",
      },
    },
  }

  if (!isMounted) {
    return (
      <div ref={containerRef} className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20">
        <div className="text-center max-w-4xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 text-transparent bg-clip-text mb-6">
            Case Studies
          </h2>
          <p className="text-xl text-gray-300">
            Explore how our AI solutions have transformed businesses across industries
          </p>
        </div>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="relative min-h-screen flex flex-col items-center justify-center px-4 py-20">
      <SafeMotion
        className="text-center max-w-4xl mx-auto mb-16"
        initial="hidden"
        animate={inView ? "visible" : "hidden"}
        variants={textVariants}
      >
        <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 text-transparent bg-clip-text mb-6">
          Case Studies
        </h2>
        <p className="text-xl text-gray-300">
          Explore how our AI solutions have transformed businesses across industries
        </p>
      </SafeMotion>

      <div className="w-full max-w-7xl mx-auto">
        {caseStudies.map((caseStudy, index) => (
          <CaseStudyCard key={index} caseStudy={caseStudy} index={index} inView={inView} />
        ))}
      </div>
    </div>
  )
}
